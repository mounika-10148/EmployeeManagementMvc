﻿using EmployeeManagement.Models;

public interface IEmployeeService
{
    Task<IEnumerable<Employee>> GetAllEmployeesAsync();
    Task<Employee> GetEmployeeByIdAsync(int id);
    Task AddEmployeeAsync(Employee employee);
    Task UpdateEmployeeAsync(Employee employee);
    Task DeleteEmployeeAsync(int id);
    Task<(List<Employee> Employees, int TotalCount)> GetPaginatedEmployeesAsync(string? searchString, int page, int pageSize);
   
    object GetSearchSuggestions(string term);
}


