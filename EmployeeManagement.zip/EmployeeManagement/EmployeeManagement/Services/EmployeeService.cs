﻿
using EmployeeManagement.Models;
using Microsoft.Extensions.Logging;

public class EmployeeService : IEmployeeService
{
    private readonly IEmployeeRepository _repository;
    private readonly ILogger<EmployeeService> _logger;

    public EmployeeService(IEmployeeRepository repository, ILogger<EmployeeService> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    /// <summary>
    /// Fetches all employees.
    /// </summary>
    /// <returns>A collection of all employees.</returns>
    public async Task<IEnumerable<Employee>> GetAllEmployeesAsync()
    {
        _logger.LogInformation("Fetching all employees.");
        return await _repository.GetAllAsync();
    }

    /// <summary>
    /// Fetches an employee by their ID.
    /// </summary>
    /// <param name="id">The ID of the employee.</param>
    /// <returns>The employee with the specified ID.</returns>
    public async Task<Employee> GetEmployeeByIdAsync(int id)
    {
        _logger.LogInformation("Fetching employee with ID {EmployeeId}", id);
        var employee = await _repository.GetByIdAsync(id);
        if (employee == null)
        {
            _logger.LogWarning("Employee with ID {EmployeeId} not found.", id);
            throw new Exception("Employee not found.");
        }
        return employee;
    }

    /// <summary>
    /// Adds a new employee.
    /// </summary>
    /// <param name="employee">The employee to add.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task AddEmployeeAsync(Employee employee)
    {
        var existingEmployees = await _repository.GetAllAsync();
        if (existingEmployees.Any(e => e.Email == employee.Email))
        {
            _logger.LogWarning("Employee with email {Email} already exists.", employee.Email);
            throw new Exception("Employee with this email already exists.");
        }

        await _repository.AddAsync(employee);
        _logger.LogInformation("Added employee with email: {Email}", employee.Email);
    }

    /// <summary>
    /// Updates an existing employee.
    /// </summary>
    /// <param name="employee">The employee to update.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task UpdateEmployeeAsync(Employee employee)
    {
        await _repository.UpdateAsync(employee);
        _logger.LogInformation("Updated employee with ID: {EmployeeId}", employee.Id);
    }

    /// <summary>
    /// Deletes an employee by their ID.
    /// </summary>
    /// <param name="id">The ID of the employee to delete.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task DeleteEmployeeAsync(int id)
    {
        await _repository.DeleteAsync(id);
        _logger.LogInformation("Deleted employee with ID: {EmployeeId}", id);
    }

    /// <summary>
    /// Fetches a paginated list of employees.
    /// </summary>
    /// <param name="searchString">The search string to filter employees.</param>
    /// <param name="page">The page number.</param>
    /// <param name="pageSize">The number of employees per page.</param>
    /// <returns>A tuple containing the list of employees and the total count.</returns>
    public async Task<(List<Employee> Employees, int TotalCount)> GetPaginatedEmployeesAsync(string? searchString, int page, int pageSize)
    {
        _logger.LogInformation("Fetching paginated employees - Page: {Page}, PageSize: {PageSize}", page, pageSize);
        return await _repository.GetPaginatedAsync(searchString, page, pageSize);
    }

    /// <summary>
    /// Fetches search suggestions for employees.
    /// </summary>
    /// <param name="term">The search term.</param>
    /// <returns>A list of search suggestions.</returns>
    public object GetSearchSuggestions(string term)
    {
        var suggestions = _repository.GetSuggestions(term);
        return suggestions;
    }
}


