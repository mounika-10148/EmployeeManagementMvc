﻿

using Dapper;
using EmployeeManagement.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;

public class EmployeeRepository : IEmployeeRepository
{
    private readonly IDbConnection _dbConnection;
    private readonly EmployeeManagementContext _context;

    public EmployeeRepository(IDbConnection dbConnection, EmployeeManagementContext context)
    {
        _dbConnection = dbConnection;
        _context = context;
    }

    /// <summary>
    /// Retrieves all employees from the database.
    /// </summary>
    /// <returns>A list of all employees.</returns>
    public async Task<IEnumerable<Employee>> GetAllAsync()
    {
        return await _context.Employees.ToListAsync();
    }

    /// <summary>
    /// Retrieves an employee by their ID.
    /// </summary>
    /// <param name="id">The ID of the employee to retrieve.</param>
    /// <returns>The employee with the specified ID, or null if not found.</returns>
    public async Task<Employee> GetByIdAsync(int id)
    {
        var sql = "SELECT * FROM Employees WHERE Id = @Id";
        return await _dbConnection.QueryFirstOrDefaultAsync<Employee>(sql, new { Id = id });
    }

    /// <summary>
    /// Adds a new employee to the database.
    /// </summary>
    /// <param name="employee">The employee to add.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task AddAsync(Employee employee)
    {
        _context.Employees.Add(employee);
        await _context.SaveChangesAsync();
    }

    /// <summary>
    /// Updates an existing employee in the database.
    /// </summary>
    /// <param name="employee">The employee with updated information.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task UpdateAsync(Employee employee)
    {
        _context.Employees.Update(employee);
        await _context.SaveChangesAsync();
    }

    /// <summary>
    /// Deletes an employee from the database by their ID.
    /// </summary>
    /// <param name="id">The ID of the employee to delete.</param>
    /// <returns>A task representing the asynchronous operation.</returns>
    public async Task DeleteAsync(int id)
    {
        var employee = await _context.Employees.FindAsync(id);
        if (employee != null)
        {
            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
        }
    }

    /// <summary>
    /// Retrieves a paginated list of employees with optional search functionality.
    /// </summary>
    /// <param name="searchString">The search term to filter employees by name, email, department, or role.</param>
    /// <param name="page">The page number to retrieve.</param>
    /// <param name="pageSize">The number of employees per page.</param>
    /// <returns>A tuple containing the list of employees and the total count of employees.</returns>
    public async Task<(List<Employee> Employees, int TotalCount)> GetPaginatedAsync(string? searchString, int page, int pageSize)
    {
        var query = _context.Employees.AsQueryable();

        if (!string.IsNullOrEmpty(searchString))
        {
            query = query.Where(e =>
                e.Name.Contains(searchString) ||
                e.Email.Contains(searchString) ||
                e.Department.Contains(searchString) ||
                e.Role.Contains(searchString));
        }

        var totalCount = await query.CountAsync();

        var employees = await query
            .OrderBy(e => e.Name)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        return (employees, totalCount);
    }

    /// <summary>
    /// Retrieves a list of employee name suggestions based on a search term.
    /// </summary>
    /// <param name="term">The search term to filter employee names.</param>
    /// <returns>A list of up to 10 distinct employee names matching the search term.</returns>
    public List<string> GetSuggestions(string term)
    {
        return _context.Employees.Where(s => s.Name.Contains(term)
            || s.Email.Contains(term) || s.Department.Contains(term)
            || s.Role.Contains(term))
            .Select(s => s.Name)
            .Distinct()
            .Take(10)
            .ToList();
    }
}

