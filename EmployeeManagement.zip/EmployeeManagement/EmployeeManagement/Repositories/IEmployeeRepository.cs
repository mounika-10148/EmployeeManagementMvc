﻿

using EmployeeManagement.Models;

public interface IEmployeeRepository
{
    Task<IEnumerable<Employee>> GetAllAsync();
    Task<Employee> GetByIdAsync(int id);
    Task AddAsync(Employee employee);
    Task UpdateAsync(Employee employee);
    Task DeleteAsync(int id);
    Task<(List<Employee> Employees, int TotalCount)> GetPaginatedAsync(string? searchString, int page, int pageSize);
    List<string> GetSuggestions(string term);

}
