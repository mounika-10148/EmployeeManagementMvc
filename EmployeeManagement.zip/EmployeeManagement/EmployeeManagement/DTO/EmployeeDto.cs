﻿namespace EmployeeManagement.DTOs
{
    public class EmployeeDto
    {
        public int Id { get; set; }  // Optional for Create, required for Update/Delete
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public DateTime DateOfJoining { get; set; }
    }
}

