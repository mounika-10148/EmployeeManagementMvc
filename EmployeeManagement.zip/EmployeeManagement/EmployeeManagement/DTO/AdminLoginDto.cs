﻿namespace EmployeeManagement.DTOs
{
    public class AdminLoginDto
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        // AQAAAAIAAYagAAAAECxv8lrpT4nt8I/iyy4aeXghNHmaO4OXoF0HTO1WkotJoUkBWCauyfTHjLU50Sf2eQ==
    }
}

