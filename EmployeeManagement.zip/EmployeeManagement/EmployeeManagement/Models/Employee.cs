﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Models;

public partial class Employee
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Name is required.")]
    [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters.")]
    public string Name { get; set; } = null!;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Invalid email address.")]
    public string Email { get; set; } = null!;

    [Required(ErrorMessage = "Department is required.")]
    [StringLength(50, ErrorMessage = "Department cannot exceed 50 characters.")]
    public string? Department { get; set; }

    [Required(ErrorMessage = "Role is required.")]
    [StringLength(50, ErrorMessage = "Role cannot exceed 50 characters.")]
    public string? Role { get; set; }

    [Required(ErrorMessage = "Date of Joining is required.")]
    [DataType(DataType.Date)]
    public DateTime? DateOfJoining { get; set; }
}
