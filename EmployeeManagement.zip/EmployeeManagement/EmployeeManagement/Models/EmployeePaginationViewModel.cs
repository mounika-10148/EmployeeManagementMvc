﻿using EmployeeManagement.Models;

namespace EmployeeManagementSystem.Models
{
    public class EmployeePaginationViewModel
    {
        public List<Employee> Employees { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public string? SearchString { get; set; }
    }

}
