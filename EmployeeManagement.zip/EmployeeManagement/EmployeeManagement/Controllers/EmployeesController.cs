﻿

using EmployeeManagement.Models;
using EmployeeManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

/// <summary>
/// Controller to manage employee-related actions, restricted to Admin role.
/// </summary>
[Authorize(Roles = "Admin")]
public class EmployeesController : Controller
{
    private readonly IEmployeeService _employeeService;
    private readonly ILogger<EmployeesController> _logger;
    private const int PageSize = 7;

    private readonly EmployeeManagementContext _dbContext;

    /// <summary>
    /// Initializes a new instance of the <see cref="EmployeesController"/> class.
    /// </summary>
    /// <param name="employeeService">The employee service.</param>
    /// <param name="logger">The logger instance.</param>
    /// <param name="dbContext">The database context.</param>
    public EmployeesController(IEmployeeService employeeService, ILogger<EmployeesController> logger, EmployeeManagementContext dbContext)
    {
        _employeeService = employeeService;
        _logger = logger;
        _dbContext = dbContext;
    }

    /// <summary>
    /// Displays a paginated list of employees with optional search functionality.
    /// </summary>
    /// <param name="searchString">The search string.</param>
    /// <param name="page">The current page number.</param>
    /// <returns>The view with the paginated list of employees.</returns>
    public async Task<IActionResult> Index(string searchString, int page = 1)
    {
        try
        {
            _logger.LogInformation("Fetching employees - Page: {Page}, Search: {Search}", page, searchString);

            var (employees, totalCount) = await _employeeService.GetPaginatedEmployeesAsync(searchString, page, PageSize);

            var viewModel = new EmployeePaginationViewModel
            {
                Employees = employees,
                CurrentPage = page,
                TotalPages = (int)Math.Ceiling(totalCount / (double)PageSize),
                SearchString = searchString
            };

            return View(viewModel);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading employee list.");
            ViewData["ErrorMessage"] = ex.Message;
            return View("Error");
        }
    }

    /// <summary>
    /// Displays details of a specific employee.
    /// </summary>
    /// <param name="id">The employee ID.</param>
    /// <returns>The view with employee details.</returns>
    public async Task<IActionResult> Details(int id)
    {
        try
        {
            _logger.LogInformation("Fetching details for employee ID: {Id}", id);

            var employee = await _employeeService.GetEmployeeByIdAsync(id);
            return View(employee);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading employee details for ID: {Id}", id);
            ViewData["ErrorMessage"] = ex.Message;
            return View("Error");
        }
    }

    /// <summary>
    /// Loads the form for creating a new employee.
    /// </summary>
    /// <returns>The create employee form view.</returns>
    public IActionResult Create()
    {
        _logger.LogInformation("Loading create employee form.");
        return View();
    }

    /// <summary>
    /// Handles the creation of a new employee.
    /// </summary>
    /// <param name="employee">The employee object to create.</param>
    /// <returns>Redirects to the index view on success, or the create view on failure.</returns>
    [HttpPost]
    public async Task<IActionResult> Create(Employee employee)
    {
        if (!ModelState.IsValid)
        {
            _logger.LogWarning("Model state invalid when creating employee.");
            return View(employee);
        }

        try
        {
            _logger.LogInformation("Creating employee: {Email}", employee.Email);

            await _employeeService.AddEmployeeAsync(employee);
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating employee: {Email}", employee.Email);
            ViewData["ErrorMessage"] = ex.Message;
            return View(employee);
        }
    }

    /// <summary>
    /// Loads the form for editing an existing employee.
    /// </summary>
    /// <param name="id">The employee ID.</param>
    /// <returns>The edit employee form view.</returns>
    public async Task<IActionResult> Edit(int id)
    {
        try
        {
            _logger.LogInformation("Loading edit form for employee ID: {Id}", id);

            var employee = await _employeeService.GetEmployeeByIdAsync(id);
            return View(employee);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading edit form for employee ID: {Id}", id);
            ViewData["ErrorMessage"] = ex.Message;
            return View("Error");
        }
    }

    /// <summary>
    /// Handles the update of an existing employee.
    /// </summary>
    /// <param name="employee">The employee object to update.</param>
    /// <returns>Redirects to the index view on success, or the edit view on failure.</returns>
    [HttpPost]
    public async Task<IActionResult> Edit(Employee employee)
    {
        if (!ModelState.IsValid)
        {
            _logger.LogWarning("Model state invalid when editing employee.");
            return View(employee);
        }

        try
        {
            _logger.LogInformation("Updating employee: {Email}", employee.Email);

            await _employeeService.UpdateEmployeeAsync(employee);
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating employee: {Email}", employee.Email);
            ViewData["ErrorMessage"] = ex.Message;
            return View(employee);
        }
    }

    /// <summary>
    /// Loads the confirmation page for deleting an employee.
    /// </summary>
    /// <param name="id">The employee ID.</param>
    /// <returns>The delete confirmation view.</returns>
    public async Task<IActionResult> Delete(int id)
    {
        try
        {
            _logger.LogInformation("Loading delete confirmation for employee ID: {Id}", id);

            var employee = await _employeeService.GetEmployeeByIdAsync(id);
            return View(employee);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading delete confirmation for employee ID: {Id}", id);
            ViewData["ErrorMessage"] = ex.Message;
            return View("Error");
        }
    }

    /// <summary>
    /// Handles the deletion of an employee.
    /// </summary>
    /// <param name="id">The employee ID.</param>
    /// <returns>Redirects to the index view on success, or the error view on failure.</returns>
    [HttpPost, ActionName("Delete")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        try
        {
            _logger.LogInformation("Deleting employee ID: {Id}", id);

            await _employeeService.DeleteEmployeeAsync(id);
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting employee ID: {Id}", id);
            ViewData["ErrorMessage"] = ex.Message;
            return View("Error");
        }
    }

    /// <summary>
    /// Provides search suggestions for employee names.
    /// </summary>
    /// <param name="term">The search term.</param>
    /// <returns>A JSON result containing search suggestions.</returns>
    [HttpGet]
    public JsonResult SearchSuggestions(string term)
    {
        var suggestions = _employeeService.GetSearchSuggestions(term);
        return Json(suggestions);
    }
}
   

