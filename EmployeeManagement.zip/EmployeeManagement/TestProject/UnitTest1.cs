﻿using EmployeeManagement.Models;
using Moq;
using Microsoft.Extensions.Logging;
using Xunit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Tests
{
    public class EmployeeServiceTests
    {
        private readonly Mock<IEmployeeRepository> _repositoryMock;
        private readonly Mock<ILogger<EmployeeService>> _loggerMock;
        private readonly EmployeeService _employeeService;

        public EmployeeServiceTests()
        {
            _repositoryMock = new Mock<IEmployeeRepository>();
            _loggerMock = new Mock<ILogger<EmployeeService>>();
            _employeeService = new EmployeeService(_repositoryMock.Object, _loggerMock.Object);
        }

        [Fact]
        // Test to verify that GetAllEmployeesAsync method returns all employees correctly
        public async Task GetAllEmployeesAsync_ShouldReturnEmployees()
        {
            // Arrange
            // Mocking a list of employees to be returned by the repository
            var employees = new List<Employee>
            {
                new Employee { Id = 1, Name = "John Doe", Email = "john@example.com" },
                new Employee { Id = 2, Name = "Jane Smith", Email = "jane@example.com" }
            };
            _repositoryMock.Setup(r => r.GetAllAsync()).ReturnsAsync(employees);

            // Act
            // Calling the service method to get all employees
            var result = await _employeeService.GetAllEmployeesAsync();

            // Assert
            // Verifying the result contains the expected number of employees and specific employee details
            Assert.Equal(2, result.Count());
            Assert.Contains(result, e => e.Name == "John Doe");
            Assert.Contains(result, e => e.Name == "Jane Smith");
        }

        [Fact]
        public async Task GetEmployeeByIdAsync_ShouldReturnEmployee_WhenEmployeeExists()
        {
            // Arrange
            var employee = new Employee { Id = 1, Name = "John Doe", Email = "john@example.com" };
            _repositoryMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(employee);

            // Act
            var result = await _employeeService.GetEmployeeByIdAsync(1);

            // Assert
            Assert.Equal("John Doe", result.Name);
            Assert.Equal("john@example.com", result.Email);
        }

        [Fact]
        public async Task GetEmployeeByIdAsync_ShouldThrowException_WhenEmployeeDoesNotExist()
        {
            // Arrange
            _repositoryMock.Setup(r => r.GetByIdAsync(It.IsAny<int>())).ReturnsAsync((Employee)null);

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _employeeService.GetEmployeeByIdAsync(999));
            Assert.Equal("Employee not found.", exception.Message);
        }

        [Fact]
        public async Task AddEmployeeAsync_ShouldAddEmployee_WhenEmailIsUnique()
        {
            // Arrange
            var employee = new Employee { Id = 1, Name = "John Doe", Email = "john@example.com" };
            _repositoryMock.Setup(r => r.GetAllAsync()).ReturnsAsync(new List<Employee>());

            // Act
            await _employeeService.AddEmployeeAsync(employee);

            // Assert
            _repositoryMock.Verify(r => r.AddAsync(It.Is<Employee>(e => e.Email == "john@example.com")), Times.Once);
        }

        [Fact]
        public async Task AddEmployeeAsync_ShouldThrowException_WhenEmailAlreadyExists()
        {
            // Arrange
            var employee = new Employee { Id = 1, Name = "John Doe", Email = "john@example.com" };
            var existingEmployees = new List<Employee>
            {
                new Employee { Id = 2, Name = "Jane Smith", Email = "john@example.com" }
            };
            _repositoryMock.Setup(r => r.GetAllAsync()).ReturnsAsync(existingEmployees);

            // Act & Assert
            var exception = await Assert.ThrowsAsync<Exception>(() => _employeeService.AddEmployeeAsync(employee));
            Assert.Equal("Employee with this email already exists.", exception.Message);
        }

        [Fact]
        public async Task UpdateEmployeeAsync_ShouldUpdateEmployee()
        {
            // Arrange
            var employee = new Employee { Id = 1, Name = "John Doe", Email = "john@example.com" };
            _repositoryMock.Setup(r => r.UpdateAsync(employee)).Returns(Task.CompletedTask);

            // Act
            await _employeeService.UpdateEmployeeAsync(employee);

            // Assert
            _repositoryMock.Verify(r => r.UpdateAsync(It.Is<Employee>(e => e.Id == 1)), Times.Once);
        }

        [Fact]
        public async Task DeleteEmployeeAsync_ShouldDeleteEmployee()
        {
            // Arrange
            _repositoryMock.Setup(r => r.DeleteAsync(It.IsAny<int>())).Returns(Task.CompletedTask);

            // Act
            await _employeeService.DeleteEmployeeAsync(1);

            // Assert
            _repositoryMock.Verify(r => r.DeleteAsync(1), Times.Once);
        }

        [Fact]
        public async Task GetPaginatedEmployeesAsync_ShouldReturnPaginatedEmployees()
        {
            // Arrange
            var employees = new List<Employee>
            {
                new Employee { Id = 1, Name = "John Doe", Email = "john@example.com" },
                new Employee { Id = 2, Name = "Jane Smith", Email = "jane@example.com" }
            };
            _repositoryMock.Setup(r => r.GetPaginatedAsync(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>()))
                .ReturnsAsync((employees, employees.Count));

            // Act
            var result = await _employeeService.GetPaginatedEmployeesAsync("John", 1, 10);

            // Assert
            Assert.Equal(2, result.Employees.Count);
            Assert.Equal(2, result.TotalCount);
        }
    }
}
